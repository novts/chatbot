const DiscoveryV1 = require("ibm-watson/discovery/v1");

async function queryDiscovery(
  environmentId,
  collectionId,
  discoveryUsername,
  discoveryPassword,
  query,
  url
) {
  // Function to query Discovery
  try {
    const discovery = new DiscoveryV1({
      version: "2019-02-01",
      username: discoveryUsername,
      password: discoveryPassword,
      url: url
    });

    const queryResult = await discovery.query({
      environment_id: environmentId,
      collection_id: collectionId,
      query: query
    });

    return queryResult;
  } catch (err) {
    return { err: err.message };
  }
}

const news = {
  async connectDiscovery(params) {
    const {
      discoveryUsername,
      discoveryPassword,
      environmentId,
      collectionId,
      input,
      url
    } = params;

    try {
      const queryString = `natural_language_query=${input}`;

      const queryResult = await queryDiscovery(
        environmentId,
        collectionId,
        discoveryUsername,
        discoveryPassword,
        queryString,
        url
      );

      const getNews = [];

      queryResult.results.forEach(result => {
        if (getNews.length <= 3) {
          const newsDisc = {
            title: result.title,
            text: result.text
          };
          getNews.push(newsDisc);
        }
      });

      return { getNews };
    } catch (err) {
      return { err: err.message };
    }
  }
};

module.exports = news;
