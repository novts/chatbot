from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
import telebot
from telebot import apihelper

#Train the bot
english_bot = ChatBot("Chatterbot", storage_adapter="chatterbot.storage.SQLStorageAdapter")
trainer = ChatterBotCorpusTrainer(english_bot)

#trainer.train("chatterbot.corpus.english")

apihelper.proxy = {'https':'socks5://127.0.0.1:9050'}

bot = telebot.TeleBot('93776t2NXPasVhvY')

@bot.message_handler(content_types=['text'])
def get_text_messages(message):
    bot.send_message(message.from_user.id, english_bot.get_response(message.text))

bot.polling()
