from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer

chatbot = ChatBot("MyAgent")

conversation = [    
"Hello! How can I help you?",
 "hello"
]

trainer = ListTrainer(chatbot)
trainer.train(conversation)

trainer.train([
    "Hi there!",
    "Good day! What can I do for you today?",
])

trainer.train([
    "hey",
    "Greetings! How can I assist?",
])

while True:
    try:
        response = chatbot.get_response(input())
        print(response)

    except(KeyboardInterrupt, EOFError, SystemExit):
        break
