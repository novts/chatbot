import urllib.request
import json
from pprint import pprint

url = 'http://localhost:5005/webhooks/rest/webhook'
values = {"sender":"John Doe","message":"Tell me some news about business"}
headers = {
    "Content-Type": "application/json",
    "Accept": "application/json",
}


data = json.dumps(values).encode("utf-8")
pprint(data)

try:
    req = urllib.request.Request(url, data, headers)
    with urllib.request.urlopen(req) as f:
        res = f.read()
    pprint(res.decode())
except Exception as e:
    pprint(e)
