from rasa_core_sdk import Action
from newsapi import NewsApiClient


class ActionGetNewst(Action):

    def name(self):
        return 'action_get_news'

    def run(self, dispatcher, tracker, domain):
        slot_category = tracker.get_slot('category')
        print(slot_category)
        newsapi = NewsApiClient(api_key='adaf0934a7e1474ab900f0832c6fbe0f')
        top_headlines = newsapi.get_top_headlines(category=slot_category,country='us', language='en')
        for article in top_headlines['articles']:
            print(article['title'])        
            dispatcher.utter_message(article['title'])
        return[]
